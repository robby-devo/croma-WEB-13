let Tv= document.getElementById("TVs");
let Tv_Show= document.getElementById("TVs_Show");
let Home= document.getElementById("Home_Appliances");
let Home_Show= document.getElementById("Home_Show");
let Phones= document.getElementById("Phones");
let Phone_Show= document.getElementById("Phone_Show");
let Computers= document.getElementById("Computers");
let Computers_Show= document.getElementById("Computers_Show");
let Kitchen= document.getElementById("Kitchen");
let Kitchen_Show= document.getElementById("Kitchen_Show");
let Audio= document.getElementById("Audio");
let Audio_Show= document.getElementById("Audio_Show");
let Health= document.getElementById("Health");
let Health_Show= document.getElementById("Health_Show");
let Grooming= document.getElementById("Grooming");
let Grooming_Show= document.getElementById("Grooming_Show");
let Cameras= document.getElementById("Cameras");
let Cameras_Show= document.getElementById("Cameras_Show");
let Smart= document.getElementById("Smart");
let Smart_Show= document.getElementById("Smart_Show");
let Gaming= document.getElementById("Gaming");
let Gaming_Show= document.getElementById("Gaming_Show");
let Accessories= document.getElementById("Accessories");
let Accessories_Show= document.getElementById("Accessories_Show");
let Brands= document.getElementById("Brands");
let Brands_Show= document.getElementById("Brands_Show");

let Menu= document.getElementById("Menu");
let Category= document.getElementById("Category");
let Cross= document.getElementById("Cross");
Menu.addEventListener("click", ()=>{
    Category.setAttribute("id", "Dis_Category");
    Menu.setAttribute("id", "Dis_Menu");
    Cross.setAttribute("id", "Dis_Cross")
})

Cross.addEventListener("click", ()=>{
    Category.setAttribute("id", "Category");
    Menu.setAttribute("id", "Menu");
    Cross.setAttribute("id", "Cross");
})

Tv.addEventListener("click", ()=>{
    Tv_Show.setAttribute("id", "Dis_Tv");
    Home_Show.setAttribute("id", "Home_Show");
    Phone_Show.setAttribute("id", "Phone_Show");
    Computers_Show.setAttribute("id", "Computers_Show");
    Kitchen_Show.setAttribute("id", "Kitchen_Show");
    Audio_Show.setAttribute("id", "Audio_Show");
    Health_Show.setAttribute("id", "Health_Show");
    Grooming_Show.setAttribute("id", "Grooming_Show");
    Cameras_Show.setAttribute("id", "Cameras_Show");
    Smart_Show.setAttribute("id", "Smart_Show");
    Gaming_Show.setAttribute("id", "Gaming_Show");
    Accessories_Show.setAttribute("id", "Accessories_Show");
    Brands_Show.setAttribute("id", "Brands_Show");
})

Home.addEventListener("click", ()=>{
    Home_Show.setAttribute("id", "Dis_Home");
    Tv_Show.setAttribute("id", "TVs_Show");
    Phone_Show.setAttribute("id", "Phone_Show");
    Computers_Show.setAttribute("id", "Computers_Show");
    Kitchen_Show.setAttribute("id", "Kitchen_Show");
    Audio_Show.setAttribute("id", "Audio_Show");
    Health_Show.setAttribute("id", "Health_Show");
    Grooming_Show.setAttribute("id", "Grooming_Show");
    Cameras_Show.setAttribute("id", "Cameras_Show");
    Smart_Show.setAttribute("id", "Smart_Show");
    Gaming_Show.setAttribute("id", "Gaming_Show");
    Accessories_Show.setAttribute("id", "Accessories_Show");
    Brands_Show.setAttribute("id", "Brands_Show");
})

Phones.addEventListener("click", ()=>{
    Phone_Show.setAttribute("id", "Dis_Phone");
    Tv_Show.setAttribute("id", "TVs_Show");
    Home_Show.setAttribute("id", "Home_Show");
    Computers_Show.setAttribute("id", "Computers_Show");
    Kitchen_Show.setAttribute("id", "Kitchen_Show");
    Audio_Show.setAttribute("id", "Audio_Show");
    Health_Show.setAttribute("id", "Health_Show");
    Grooming_Show.setAttribute("id", "Grooming_Show");
    Cameras_Show.setAttribute("id", "Cameras_Show");
    Smart_Show.setAttribute("id", "Smart_Show");
    Gaming_Show.setAttribute("id", "Gaming_Show");
    Accessories_Show.setAttribute("id", "Accessories_Show");
    Brands_Show.setAttribute("id", "Brands_Show");
})

Computers.addEventListener("click", ()=>{
    Computers_Show.setAttribute("id", "Dis_Computer");
    Tv_Show.setAttribute("id", "TVs_Show");
    Home_Show.setAttribute("id", "Home_Show");
    Phone_Show.setAttribute("id", "Phone_Show");
    Kitchen_Show.setAttribute("id", "Kitchen_Show");
    Audio_Show.setAttribute("id", "Audio_Show");
    Health_Show.setAttribute("id", "Health_Show");
    Grooming_Show.setAttribute("id", "Grooming_Show");
    Cameras_Show.setAttribute("id", "Cameras_Show");
    Smart_Show.setAttribute("id", "Smart_Show");
    Gaming_Show.setAttribute("id", "Gaming_Show");
    Accessories_Show.setAttribute("id", "Accessories_Show");
    Brands_Show.setAttribute("id", "Brands_Show");
})

Kitchen.addEventListener("click", ()=>{
    Kitchen_Show.setAttribute("id", "Dis_Kitchen");
    Tv_Show.setAttribute("id", "TVs_Show");
    Home_Show.setAttribute("id", "Home_Show");
    Phone_Show.setAttribute("id", "Phone_Show");
    Computers_Show.setAttribute("id", "Computers_Show");
    Audio_Show.setAttribute("id", "Audio_Show");
    Health_Show.setAttribute("id", "Health_Show");
    Grooming_Show.setAttribute("id", "Grooming_Show");
    Cameras_Show.setAttribute("id", "Cameras_Show");
    Smart_Show.setAttribute("id", "Smart_Show");
    Gaming_Show.setAttribute("id", "Gaming_Show");
    Accessories_Show.setAttribute("id", "Accessories_Show");
    Brands_Show.setAttribute("id", "Brands_Show");
})

Audio.addEventListener("click", ()=>{
    Audio_Show.setAttribute("id", "Dis_Audio");
    Tv_Show.setAttribute("id", "TVs_Show");
    Home_Show.setAttribute("id", "Home_Show");
    Phone_Show.setAttribute("id", "Phone_Show");
    Computers_Show.setAttribute("id", "Computers_Show");
    Kitchen_Show.setAttribute("id", "Kitchen_Show");
    Health_Show.setAttribute("id", "Health_Show");
    Grooming_Show.setAttribute("id", "Grooming_Show");
    Cameras_Show.setAttribute("id", "Cameras_Show");
    Smart_Show.setAttribute("id", "Smart_Show");
    Gaming_Show.setAttribute("id", "Gaming_Show");
    Accessories_Show.setAttribute("id", "Accessories_Show");
    Brands_Show.setAttribute("id", "Brands_Show");
})

Health.addEventListener("click", ()=>{
    Health_Show.setAttribute("id", "Dis_Health");
    Tv_Show.setAttribute("id", "TVs_Show");
    Home_Show.setAttribute("id", "Home_Show");
    Phone_Show.setAttribute("id", "Phone_Show");
    Computers_Show.setAttribute("id", "Computers_Show");
    Kitchen_Show.setAttribute("id", "Kitchen_Show");
    Audio_Show.setAttribute("id", "Audio_Show");
    Grooming_Show.setAttribute("id", "Grooming_Show");
    Cameras_Show.setAttribute("id", "Cameras_Show");
    Smart_Show.setAttribute("id", "Smart_Show");
    Gaming_Show.setAttribute("id", "Gaming_Show");
    Accessories_Show.setAttribute("id", "Accessories_Show");
    Brands_Show.setAttribute("id", "Brands_Show");
})

Grooming.addEventListener("click", ()=>{
    Grooming_Show.setAttribute("id", "Dis_Grooming");
    Tv_Show.setAttribute("id", "TVs_Show");
    Home_Show.setAttribute("id", "Home_Show");
    Phone_Show.setAttribute("id", "Phone_Show");
    Computers_Show.setAttribute("id", "Computers_Show");
    Kitchen_Show.setAttribute("id", "Kitchen_Show");
    Audio_Show.setAttribute("id", "Audio_Show");
    Health_Show.setAttribute("id", "Health_Show");
    Cameras_Show.setAttribute("id", "Cameras_Show");
    Smart_Show.setAttribute("id", "Smart_Show");
    Gaming_Show.setAttribute("id", "Gaming_Show");
    Accessories_Show.setAttribute("id", "Accessories_Show");
    Brands_Show.setAttribute("id", "Brands_Show");
})

Cameras.addEventListener("click", ()=>{
    Cameras_Show.setAttribute("id", "Dis_Cameras");
    Tv_Show.setAttribute("id", "TVs_Show");
    Home_Show.setAttribute("id", "Home_Show");
    Phone_Show.setAttribute("id", "Phone_Show");
    Computers_Show.setAttribute("id", "Computers_Show");
    Kitchen_Show.setAttribute("id", "Kitchen_Show");
    Audio_Show.setAttribute("id", "Audio_Show");
    Health_Show.setAttribute("id", "Health_Show");
    Grooming_Show.setAttribute("id", "Grooming_Show");
    Smart_Show.setAttribute("id", "Smart_Show");
    Gaming_Show.setAttribute("id", "Gaming_Show");
    Accessories_Show.setAttribute("id", "Accessories_Show");
    Brands_Show.setAttribute("id", "Brands_Show");
})

Smart.addEventListener("click", ()=>{
    Smart_Show.setAttribute("id", "Dis_Smart");
    Tv_Show.setAttribute("id", "TVs_Show");
    Home_Show.setAttribute("id", "Home_Show");
    Phone_Show.setAttribute("id", "Phone_Show");
    Computers_Show.setAttribute("id", "Computers_Show");
    Kitchen_Show.setAttribute("id", "Kitchen_Show");
    Audio_Show.setAttribute("id", "Audio_Show");
    Health_Show.setAttribute("id", "Health_Show");
    Grooming_Show.setAttribute("id", "Grooming_Show");
    Cameras_Show.setAttribute("id", "Cameras_Show");
    Gaming_Show.setAttribute("id", "Gaming_Show");
    Accessories_Show.setAttribute("id", "Accessories_Show");
    Brands_Show.setAttribute("id", "Brands_Show");
})

Gaming.addEventListener("click", ()=>{
    Gaming_Show.setAttribute("id", "Dis_Gaming");
    Tv_Show.setAttribute("id", "TVs_Show");
    Home_Show.setAttribute("id", "Home_Show");
    Phone_Show.setAttribute("id", "Phone_Show");
    Computers_Show.setAttribute("id", "Computers_Show");
    Kitchen_Show.setAttribute("id", "Kitchen_Show");
    Audio_Show.setAttribute("id", "Audio_Show");
    Health_Show.setAttribute("id", "Health_Show");
    Grooming_Show.setAttribute("id", "Grooming_Show");
    Cameras_Show.setAttribute("id", "Cameras_Show");
    Smart_Show.setAttribute("id", "Smart_Show");
    Accessories_Show.setAttribute("id", "Accessories_Show");
    Brands_Show.setAttribute("id", "Brands_Show");
})

Accessories.addEventListener("click", ()=>{
    Accessories_Show.setAttribute("id", "Dis_Accessories");
    Tv_Show.setAttribute("id", "TVs_Show");
    Home_Show.setAttribute("id", "Home_Show");
    Phone_Show.setAttribute("id", "Phone_Show");
    Computers_Show.setAttribute("id", "Computers_Show");
    Kitchen_Show.setAttribute("id", "Kitchen_Show");
    Audio_Show.setAttribute("id", "Audio_Show");
    Health_Show.setAttribute("id", "Health_Show");
    Grooming_Show.setAttribute("id", "Grooming_Show");
    Cameras_Show.setAttribute("id", "Cameras_Show");
    Smart_Show.setAttribute("id", "Smart_Show");
    Gaming_Show.setAttribute("id", "Gaming_Show");
    Brands_Show.setAttribute("id", "Brands_Show");
})

Brands.addEventListener("click", ()=>{
    Brands_Show.setAttribute("id", "Dis_Brand");
    Tv_Show.setAttribute("id", "TVs_Show");
    Home_Show.setAttribute("id", "Home_Show");
    Phone_Show.setAttribute("id", "Phone_Show");
    Computers_Show.setAttribute("id", "Computers_Show");
    Kitchen_Show.setAttribute("id", "Kitchen_Show");
    Audio_Show.setAttribute("id", "Audio_Show");
    Health_Show.setAttribute("id", "Health_Show");
    Grooming_Show.setAttribute("id", "Grooming_Show");
    Cameras_Show.setAttribute("id", "Cameras_Show");
    Smart_Show.setAttribute("id", "Smart_Show");
    Gaming_Show.setAttribute("id", "Gaming_Show");
    Accessories_Show.setAttribute("id", "Accessories_Show");
})
function Sign(){
    let div=document.getElementById("SignUp");
    div.style.display="block"
}
function close1(){
    let div=document.getElementById("SignUp");
    div.style.display="none"
}
function close2(){
    let div=document.getElementById("Signin");
    div.style.display="none"
}
document.querySelector('form').addEventListener('submit',function(e){
    e.preventDefault();
    var na=form.name1.value;
    var nu=form.mobile.value;
    var em=form.email.value;
    var ps=form.pass.value;
    if(na.length<3)
    {
        alert("Enter Name")
    }
    else if(nu.length!==10)
    {
        alert("Enter Correct Number")
    }
    else if(em.length<5)
    {
        alert("Enter Email")
    }
    else if(ps.length<8)
    {
        alert("Enter Strong Password")
    }
    else
    {
       let pro=document.getElementById("submit");
       pro.textContent="Proccesing"
      let div=document.getElementById('pro')
      div.style.display="block"
 
    setTimeout(()=>{
       
     let signup_details={
         name:form.name1.value,
         email:form.email.value,
         password:form.pass.value,
         username:form.username.value,
         mobile:form.mobile.value,
         description:form.description.value,
     }
      signup_details=JSON.stringify(signup_details)
     Register()
   async  function Register(){
      let signup_api="https://masai-api-mocker.herokuapp.com/auth/register";
  let response=await fetch(signup_api,{
         method:'POST',
         body:signup_details,
         headers:{
             'Content-Type':'application/json'
         }
         })
     let data=await response.json();
     console.log(data)
     if(data.error==true)
     {
         alert("Registration failed, user already exists")
         let pro=document.getElementById("submit");
       pro.textContent="Submit"
      let div=document.getElementById('pro')
      div.style.display="none"
     }
     else{
         alert("Account Succesfully Created")
         let div=document.getElementById('SignUp')
         div.style.display="none"
        let div2=document.getElementById('Signin')
        div2.style.display="block"
     }
}
},2000)
} })

/// function 
function Sin()
{
let div=document.getElementById('Signin')
let div2=document.getElementById('SignUp')
div2.style.display="none"
div.style.display="block" 
}

function SIgn(){
let login={
    username:document.getElementById('usernameIn').value,
    password:document.getElementById('passIn').value,
}
login=JSON.stringify(login)
let pro=document.getElementById("submit1");
       pro.textContent="Proccesing"
      let div=document.getElementById('pro1')
      div.style.display="block"
 
 loginV()
async function loginV(){
let login_api='https://masai-api-mocker.herokuapp.com/auth/login';
let response=await fetch(login_api,{
    method:'POST',
    body:login,
    headers:{
        'Content-Type':'application/json'
    }
})
let data=await response.json()
console.log(data)
console.log(data.error)
if(data.error==true)
{
    
    let pro=document.getElementById("submit");
       pro.textContent="Submit"
      let div=document.getElementById('pro1')
      div.style.display="none"
      alert("Invalid login creadentials")
}
else{
    let usernameU=document.getElementById('usernameIn').value;
    localStorage.setItem("UsernameU",usernameU)
    alert("login Successful")
    location.href="CromaPhones.html";
   
}
}
}
document.getElementById('logo').addEventListener('click',()=>{
    location.href='home.html';
})